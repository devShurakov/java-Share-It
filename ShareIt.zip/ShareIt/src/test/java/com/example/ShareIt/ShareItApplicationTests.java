package com.example.ShareIt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShareItApplicationTests {

	@Test
	void contextLoads() {
	}

}
