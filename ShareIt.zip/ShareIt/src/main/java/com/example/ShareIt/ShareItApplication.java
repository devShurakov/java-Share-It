package com.example.ShareIt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShareItApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShareItApplication.class, args);
	}

}
